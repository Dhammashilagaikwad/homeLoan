import React, { useRef } from "react";
import Highcharts from "highcharts";


export default function Content() {

  const text1 = useRef();
  const text2 = useRef();
  const text3 = useRef();
  const para = useRef();
  const chartRef = useRef();
  //  console.log(text1,text2,text3,para)

  function myFunc1() {
    console.log("test");

    var amount = text1.current.value;
    var roi = text2.current.value;
    var duration = text3.current.value;
    console.log(amount, roi, duration);

    var message;
    if (amount == '' || roi == '' || duration == '') {
      message = 'all values r required';
      para.current.className = 'alert alert-danger';
    } else {
      if (isNaN(amount) || isNaN(roi) || isNaN(duration)) {
        message = 'all values must be a number';
        para.current.className = 'alert alert-danger';
      } else {
        if (amount <= 0 || roi <= 0 || duration <= 0) {
          message = 'all values must be positive number';
          para.current.className = 'alert alert-danger';
        }
        else {
          amount = +amount;
          roi = +roi;
          duration = +duration;

          duration = duration * 12;
          roi = roi / 12 / 100;

          var emi = amount * roi * (1 + roi) ** duration / ((1 + roi) ** duration - 1);
          console.log("Emi", emi);

          var totalPayable = emi * duration;
          console.log(totalPayable);

          var interest = totalPayable - amount;
          console.log(interest);


          message = `
           Loan Amount: ${amount} <br />
        Emi: ${Math.round(emi)} <br />
        Interest: ${Math.round(interest)} <br />
        Total Paid: ${Math.round(totalPayable)} <br />
        `;
          para.current.className = 'alert alert-success';

          Highcharts.chart(chartRef.current,{
            chart: {
              type:'column'
            },
            title: {
              text: 'Loan Breakdown'
            },
            xAxis: {
              categories: ['Loan Amount', 'Interest', 'Total Paid']
            },
            yAxis:{
              title:{
                text: 'Amount in ₹ '
              }
            },
            series: [{
              name: 'Loan Details',
              data:[amount, Math.round(interest), Math.round(totalPayable)],
              colorByPoint:true
            }]
          });
        }
      }
    }

    para.current.innerHTML = message;

  }


  return (
    <>
      <div class="container">
        <h1>Home Loan Calculator</h1>
        <hr />
        <input ref={text1} placeholder="Amount" className="form-control" />  <br />
        <input ref={text2} placeholder="roi" className="form-control" /> <br />
        <input ref={text3} placeholder="duration" className="form-control" /> <br /> <br />
        <button onClick={myFunc1} className="btn btn-sm bg-primary">Calculator</button> <br />
        <p ref={para} >...</p>
        <div ref={chartRef}></div>
      </div>
    </>
  )
}

