import React from "react";
import { BrowserRouter, Routes, Route } from "react-router";
import App from "./App";
import Content from "./Content";
import Register from "./Register";
import Login from "./Login";
import User from "./User";
import Adduser from "./Adduser";
import Showuser from "./Showuser";
import Product from "./Product";
import Pagenotfound from "./Pagenotfound";

var projectroute = (
    <BrowserRouter>
        <Routes>
            <Route path="/" element={<App />}>
                <Route path="" element={<Content />} />
                <Route path="register-page" element={<Register />} />
                <Route path="login-page" element={<Login />} />
                <Route path="user" element={<User />}>
                    <Route path="add" element={<Adduser />} />
                    <Route path="show" element={<Showuser />} />
                </Route>
                <Route path="product/:productId" element={<Product />} />
                <Route path="*" element={<Pagenotfound />} />
            </Route>
        </Routes>
    </BrowserRouter>
)

export default projectroute;