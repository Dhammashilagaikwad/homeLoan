import React from "react";
import { Outlet } from "react-router";

function User() {
    return (
        <>

            <Outlet />

        </>
    )
}

export default User;