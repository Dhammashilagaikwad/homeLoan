import React, { useRef } from "react";
import { useParams } from "react-router";

function Product() {
    let params = useParams();
    // console.log(params);
    const amount = useRef();
    const quantiy = useRef();
    const final = useRef();

    const discAmount = useRef();
    const discCount = useRef();
    const discountedPrice = useRef();
    const discFinal = useRef();

    function handleCal() {
        // console.log("test");
        var amnt = amount.current.value;
        var qunt = quantiy.current.value;

        var result = amnt * qunt;

        final.current.innerHTML = result;
    }

    function discountCal() {
        // console.log("test");
        var discountAmount = discAmount.current.value;
        var discount = discCount.current.value;

        var discountPrice = (discountAmount * discount) / 100;
        console.log(discountPrice)
        var result = discountAmount - discountPrice;

        discountedPrice.current.innerHTML = discountPrice;
        discFinal.current.innerHTML = result;

    }
    return (
        <>
            <h1>
                products
            </h1>
            <hr />


            <h1>Amount Quantity Calculator</h1>
            <label>Amount : </label>
            <input type="number" ref={amount} placeholder="Enter Amount" />
            <br />
            <label>Quantity :  </label>
            <input type="number" ref={quantiy} placeholder="Enter Quantity" />
            <br />

            <button onClick={handleCal}>Calculator</button>
            <br />
            <label>Final :<span ref={final}></span></label>
            <br />
            <hr />

            <h1>Discount Calculator</h1>
            <label>Amount : </label>
            <input type="number" ref={discAmount} placeholder="Enter Amount" />
            <br />
            <label>discount : </label>
            <input type="number" ref={discCount} placeholder="Enter discount %" />
            <br />

            <button onClick={discountCal}>Calculator</button>
            <br />
            <label>discountedPrice: <span ref={discountedPrice}></span></label>
            <br />
            <label>Final: <span ref={discFinal}></span></label>
        </>
    )
}

export default Product;